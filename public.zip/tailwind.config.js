/** @type {import('tailwindcss').Config} */
module.exports = {
  // CRITICAL: Tells Tailwind to scan all React and TypeScript files in src/
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}