import axios, { type AxiosInstance, AxiosError, type  InternalAxiosRequestConfig } from 'axios';

// 1. Base URL Configuration
const apiClient: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'https://api.production.com/v1',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// 2. Session Management (Request Interceptor)
apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('auth_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error)
);

// 3. Error Handling (Response Interceptor)
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    // Global error handling (e.g., redirect on 401)
    if (error.response?.status === 401) {
      localStorage.removeItem('auth_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default apiClient;