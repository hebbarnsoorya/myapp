import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
// Update the import path to the new SCSS file
import './index.scss'; 

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);