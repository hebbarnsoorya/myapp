// Define the structure of the data expected by the Dashboard
export interface KPICardData {
  title: string;
  value: string;
  trend: string;
  trendUp: boolean;
  iconType: 'DollarSign' | 'Users' | 'Activity' | 'TrendingUp';
}

export interface ChartDataPoint {
  name: string;
  value: number;
}

export interface DashboardData {
  kpis: KPICardData[];
  chartData: ChartDataPoint[];
}