import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { MainLayout } from './components/layout/MainLayout'; // Import Layout
import { ProtectedRoute } from './components/layout/ProtectedRoute';
import { LoginForm } from './features/auth/LoginForm';
import { Dashboard } from './pages/Dashboard';
import { UsersPage } from './pages/Users';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Routes (No Layout or Simplified Layout) */}
          <Route path="/login" element={<div className="h-screen flex items-center justify-center bg-slate-100"><LoginForm /></div>} />

          {/* Application Routes (Wrapped in MainLayout) */}
          <Route element={<MainLayout />}>
            
            {/* Protected Area */}
            <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
            {/* Add the new page route here */}
            <Route path="/users" element={<UsersPage />} /> 
            
          </Route>
            
          </Route>

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;