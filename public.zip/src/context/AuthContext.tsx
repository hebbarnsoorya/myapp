import React, { createContext, useReducer, type  ReactNode } from 'react';

// Types
interface AuthState {
  isAuthenticated: boolean;
  user: { name: string; role: string } | null;
}

type AuthAction = 
  | { type: 'LOGIN'; payload: { name: string; role: string } }
  | { type: 'LOGOUT' };

// Initial State
const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
};

// Reducer
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN':
      return { isAuthenticated: true, user: action.payload };
    case 'LOGOUT':
      return { isAuthenticated: false, user: null };
    default:
      return state;
  }
};

export const AuthContext = createContext<{
  state: AuthState;
  dispatch: React.Dispatch<AuthAction>;
}>({ state: initialState, dispatch: () => null });

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);
  return (
    <AuthContext.Provider value={{ state, dispatch }}>
      {children}
    </AuthContext.Provider>
  );
};