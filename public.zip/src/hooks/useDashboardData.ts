import { useState, useEffect } from 'react';
import { dashboardService } from '../services/dashboardService';
import { type DashboardData } from '../types/dashboard';

interface DashboardHookState {
  data: DashboardData | null;
  isLoading: boolean;
  error: string | null;
}

export const useDashboardData = (): DashboardHookState => {
  const [state, setState] = useState<DashboardHookState>({
    data: null,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    // 1. Initialize AbortController for cleanup
    const controller = new AbortController();
    const signal = controller.signal;

    const fetchData = async () => {
      setState(prev => ({ ...prev, isLoading: true, error: null })); // Start loading, clear errors

      try {
        // 2. Pass signal to the API call
        const fetchedData = await dashboardService.fetchData(signal);
        
        // 3. Update state only if request wasn't aborted
        if (!signal.aborted) {
          setState({ data: fetchedData, isLoading: false, error: null });
        }
      } catch (err) {
        // 4. Handle errors (excluding intentional aborts)
        if (err instanceof DOMException && err.name === 'AbortError') {
          console.log('Fetch request aborted successfully.');
          return; 
        }
        
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch dashboard data.';
        setState(prev => ({ ...prev, isLoading: false, error: errorMessage }));
      }
    };

    fetchData();

    // 5. Cleanup function: Abort the fetch request when component unmounts
    return () => {
      console.log('Cleaning up fetch request...');
      controller.abort();
    };
  }, []); // Empty dependency array means run once on mount

  return state;
};