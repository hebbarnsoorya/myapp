import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useContext, useState } from 'react';
import { AuthContext } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { authService } from '../../services/authService'; // Import the new service
import { AlertCircle } from 'lucide-react'; // For error display

// Zod Schema (unchanged)
const loginSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});
type LoginSchemaType = z.infer<typeof loginSchema>;


export const LoginForm = () => {
  const { dispatch } = useContext(AuthContext);
  const navigate = useNavigate();
  const [apiError, setApiError] = useState<string | null>(null); // State for API errors

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginSchemaType>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: 'admin@test.com', password: 'password123' } // Helpful default for testing
  });

  const onSubmit = async (data: LoginSchemaType) => {
    setApiError(null); // Clear previous errors
    try {
      // 1. Call the API Service
      const response = await authService.login(data);

      // 2. Client-Side Session Management: Store the token
      localStorage.setItem('auth_token', response.token);

      // 3. Update the global Auth state (Reducer)
      dispatch({ type: 'LOGIN', payload: response.user });

      // 4. Redirect to the Protected Route (Dashboard)
      navigate('/dashboard', { replace: true });

    } catch (error) {
      // 5. Error Handling and Proper Error Display
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred.";
      setApiError(errorMessage);
      console.error("Login failed:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-6 bg-white rounded-xl shadow-2xl border border-gray-100 w-full max-w-sm">
      <h2 className="text-2xl font-bold text-center text-slate-800">Sign In to DataCorp</h2>

      {/* Error Display */}
      {apiError && (
        <div role="alert" className="flex items-center p-3 text-sm text-red-700 bg-red-100 rounded-lg border border-red-300">
          <AlertCircle size={18} className="mr-2 shrink-0" />
          <p className="font-medium">{apiError}</p>
        </div>
      )}

      {/* Email Field */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Email</label>
        <input 
          {...register('email')} 
          type="email"
          className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm p-2 border focus:ring-indigo-500 focus:border-indigo-500 ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
          disabled={isSubmitting}
        />
        {errors.email && <span className="text-xs text-red-500 font-medium">{errors.email.message}</span>}
      </div>

      {/* Password Field */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Password</label>
        <input 
          type="password"
          {...register('password')}
          className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-indigo-500 focus:border-indigo-500 ${errors.password ? 'border-red-500' : 'border-gray-300'}`}
          disabled={isSubmitting}
        />
        {errors.password && <span className="text-xs text-red-500 font-medium">{errors.password.message}</span>}
      </div>

      {/* Submit Button */}
      <button 
        type="submit" 
        disabled={isSubmitting}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 transition-all duration-200 mt-6"
      >
        {isSubmitting ? 'Authenticating...' : 'Sign In'}
      </button>
    </form>
  );
};