import { type DashboardData } from '../types/dashboard';
import apiClient from '../lib/axios'; // Use our configured Axios instance

export const dashboardService = {
  fetchData: async (signal: AbortSignal): Promise<DashboardData> => {
    // In production, replace this mock with:
    // const response = await apiClient.get('/dashboard/summary', { signal });
    // return response.data;

    console.log("Simulating fetching Dashboard data...");
    
    // --- MOCK API RESPONSE (Simulate 1.5 seconds latency) ---
    await new Promise(resolve => setTimeout(resolve, 1500));

    if (signal.aborted) {
      // If the component unmounted during the delay, throw an AbortError
      throw new DOMException('Request aborted by component unmount', 'AbortError');
    }

    // Mock data compliant with the DashboardData interface
    return {
      kpis: [
        { title: "Total Revenue", value: "$54,230", trend: "+12%", trendUp: true, iconType: 'DollarSign' },
        { title: "Active Users", value: "2,345", trend: "+5%", trendUp: true, iconType: 'Users' },
        { title: "Bounce Rate", value: "42.3%", trend: "-2%", trendUp: false, iconType: 'Activity' },
        { title: "Sales", value: "1,203", trend: "-14%", trendUp: false, iconType: 'TrendingUp' },
      ],
      chartData: [
        { name: 'Jan', value: 4000 },
        { name: 'Feb', value: 3000 },
        { name: 'Mar', value: 5000 },
        { name: 'Apr', value: 2780 },
        { name: 'May', value: 1890 },
        { name: 'Jun', value: 2390 },
        { name: 'Jul', value: 3490 },
      ],
    };
  },
};