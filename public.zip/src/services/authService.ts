import apiClient from '../lib/axios';

interface LoginCredentials {
  email: string;
  password: string;
}

interface LoginResponse {
  token: string;
  user: { name: string; role: string };
}

// NOTE: This function simulates a production API call
export const authService = {
  login: async (credentials: LoginCredentials): Promise<LoginResponse> => {
    // In a real application, replace this mock with:
    // const response = await apiClient.post('/auth/login', credentials);
    // return response.data;
    
    console.log("Simulating API Login for:", credentials.email);

    // --- MOCK API RESPONSE ---
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network latency

    if (credentials.email === "admin@test.com" && credentials.password === "password123") {
      const mockToken = `mock-jwt-token-for-${Date.now()}`;
      return {
        token: mockToken,
        user: { name: "Alex DataCorp", role: "Admin" }
      };
    } else {
      throw new Error("Invalid email or password.");
    }
  },
};