import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { AnalyticsChart } from '../features/dashboard/AnalyticsChart';
import { useDashboardData } from '../hooks/useDashboardData'; // Import the new hook
import { DollarSign, Users, Activity, TrendingUp, AlertTriangle, Loader2 } from 'lucide-react';
import { type KPICardData } from '../types/dashboard'; // Import types

// Helper function to map string type to actual Lucide Icon component
const getIcon = (iconType: KPICardData['iconType']) => {
    switch (iconType) {
        case 'DollarSign': return <DollarSign size={24} />;
        case 'Users': return <Users size={24} />;
        case 'Activity': return <Activity size={24} />;
        case 'TrendingUp': return <TrendingUp size={24} />;
        default: return null;
    }
}

// --- Sub-Component: KPI Card (Updated to accept full data object) ---
const StatCard: React.FC<KPICardData> = (props) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500">{props.title}</p>
        <h3 className="text-2xl font-bold text-slate-800 mt-1">{props.value}</h3>
      </div>
      <div className="p-3 bg-indigo-50 rounded-lg text-indigo-600">
        {getIcon(props.iconType)}
      </div>
    </div>
    <div className="mt-4 flex items-center text-sm">
      <span className={props.trendUp ? "text-green-500 font-medium" : "text-red-500 font-medium"}>
        {props.trend}
      </span>
      <span className="text-slate-400 ml-2">vs last month</span>
    </div>
  </div>
);

// --- Main Page Component ---
export const Dashboard = () => {
  const { state: authState, dispatch } = useContext(AuthContext);
  const { data, isLoading, error } = useDashboardData(); // Consume the hook

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
  };
  
  // --- Conditional Rendering for Loading and Error States ---
  if (error) {
    return (
      <div className="p-10 text-center bg-red-50 text-red-700 border border-red-200 rounded-lg m-8">
        <AlertTriangle size={32} className="mx-auto mb-2" />
        <p className="font-bold">Data Fetch Error: </p>
        <p className="text-sm">{error}</p>
      </div>
    );
  }

  // Display a clean loading indicator
  if (isLoading) {
    return (
        <div className="flex items-center justify-center p-20 text-indigo-600">
            <Loader2 className="animate-spin mr-3" size={24} />
            <p className="font-medium">Loading Dashboard Data...</p>
        </div>
    );
  }
  
  // Guard check (Data should exist here, but TS requires checking)
  if (!data) return null; 

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-entry">
      
      {/* 1. Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Overview</h1>
          <p className="text-slate-500 mt-1">
            Welcome back, **{authState.user?.name || 'Admin'}**. Here is what's happening today.
          </p>
        </div>
        <button 
            onClick={handleLogout}
            className="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 font-medium transition-colors"
        >
            Logout
        </button>
      </div>

      {/* 2. KPI Grid (Populated from hook data) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {data.kpis.map((kpi, index) => (
            <StatCard key={index} {...kpi} />
        ))}
      </div>

      {/* 3. Main Content Grid (Chart + Recent Activity) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left: Main Chart (Populated from hook data) */}
        <div className="lg:col-span-2">
          <AnalyticsChart data={data.chartData} title="Revenue Analytics" />
        </div>

        {/* Right: Recent Activity / Notifications */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-96 overflow-y-auto">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Recent Activity</h3>
          {/* Mock Activity List */}
          <ul className="space-y-4">
            {[1, 2, 3].map((item) => (
              <li key={item} className="flex items-start gap-3 pb-3 border-b border-slate-100 last:border-0">
                <div className="w-2 h-2 mt-2 rounded-full bg-indigo-500 shrink-0" />
                <div>
                  <p className="text-sm text-slate-700 font-medium">Order #{1023 + item} processed</p>
                  <p className="text-xs text-slate-400">{(4 * item)} minutes ago</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};