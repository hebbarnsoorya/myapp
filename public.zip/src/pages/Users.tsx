import React, { useState, useMemo } from 'react';
import { DataTable } from '../components/common/DataTable';
import { DataFilters } from '../components/common/DataFilters';

// 1. Strict Typing for Table Data
interface UserRecord {
  id: number;
  name: string;
  email: string;
  role: 'Admin' | 'User' | 'Guest';
  status: 'Active' | 'Pending' | 'Archived';
  lastActivity: Date;
}

// Mock Data Source
const mockUsers: UserRecord[] = [
  { id: 101, name: 'Alex Johnson', email: 'alex@corp.com', role: 'Admin', status: 'Active', lastActivity: new Date('2025-12-01') },
  { id: 102, name: 'Sarah Connor', email: 'sarah@corp.com', role: 'User', status: 'Pending', lastActivity: new Date('2025-11-28') },
  { id: 103, name: 'Mike Miller', email: 'mike@corp.com', role: 'User', status: 'Active', lastActivity: new Date('2025-11-30') },
  { id: 104, name: 'Jane Doe', email: 'jane@corp.com', role: 'Guest', status: 'Archived', lastActivity: new Date('2025-10-15') },
  // ... (Add 10-15 more items for pagination to work well)
];

export const UsersPage = () => {
  const [filters, setFilters] = useState({ query: '', status: 'all' });
  
  // 2. Filtering Logic (Memoized)
  const filteredUsers = useMemo(() => {
    return mockUsers.filter(user => {
      // Status Filter
      if (filters.status !== 'all' && user.status !== filters.status) {
        return false;
      }
      
      // Search Query Filter
      if (filters.query) {
        const lowerQuery = filters.query.toLowerCase();
        return (
          user.name.toLowerCase().includes(lowerQuery) ||
          user.id.toString().includes(lowerQuery)
        );
      }
      
      return true;
    });
  }, [filters]);

  // 3. Column Definitions (Strictly typed)
  const columns = useMemo(() => [
    { key: 'id', header: 'ID' },
    { key: 'name', header: 'User Name' },
    { key: 'email', header: 'Email' },
    { key: 'role', header: 'Role' },
    { 
      key: 'status', 
      header: 'Status', 
      // Custom rendering for visual indicators
      render: (user: UserRecord) => (
        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
          ${user.status === 'Active' ? 'bg-green-100 text-green-800' : 
            user.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 
            'bg-red-100 text-red-800'}`}
        >
          {user.status}
        </span>
      ),
    },
    { 
      key: 'actions', 
      header: 'Actions', 
      // Custom actions button
      render: (user: UserRecord) => (
        <button 
          onClick={() => alert(`Viewing details for ${user.name}`)}
          className="text-indigo-600 hover:text-indigo-900 text-sm font-medium"
        >
          View
        </button>
      ),
    },
  ], []);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-entry">
      <h1 className="text-3xl font-bold text-slate-900">User Management</h1>
      
      {/* 4. Filter Component Integration */}
      <DataFilters onFilterChange={setFilters} />
      
      {/* 5. Data Table Component Integration */}
      <DataTable<UserRecord> 
        data={filteredUsers} 
        columns={columns} 
        itemsPerPage={5} // Setting to 5 to clearly show pagination
      />
    </div>
  );
};