import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';

interface DataFiltersProps {
  onFilterChange: (filters: { query: string; status: string }) => void;
}

export const DataFilters: React.FC<DataFiltersProps> = ({ onFilterChange }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Utility function to notify parent component
  const handleFilterUpdate = (newQuery: string, newStatus: string) => {
    onFilterChange({ query: newQuery, status: newStatus });
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    // Debouncing would be used here in production to prevent excessive updates
    handleFilterUpdate(query, statusFilter);
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const status = e.target.value;
    setStatusFilter(status);
    handleFilterUpdate(searchQuery, status);
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4 p-4 bg-white rounded-xl border border-slate-200">
      {/* Search Input */}
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
        <input
          type="text"
          placeholder="Search by name or ID..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-colors text-sm"
        />
      </div>

      {/* Status Filter Dropdown */}
      <div className="relative">
        <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
        <select
          value={statusFilter}
          onChange={handleStatusChange}
          className="w-full appearance-none pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-colors text-sm bg-white"
        >
          <option value="all">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Pending">Pending</option>
          <option value="Archived">Archived</option>
        </select>
      </div>
    </div>
  );
};