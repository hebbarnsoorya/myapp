import React, { useState, useMemo } from 'react';
import { ArrowUp, ArrowDown, ChevronLeft, ChevronRight } from 'lucide-react';

// 1. Generic Props for Type Safety (T extends object allows any object type)
interface DataTableProps<T extends object> {
  data: T[];
  columns: {
    key: keyof T | 'actions'; // 'actions' for buttons/links column
    header: string;
    render?: (item: T) => React.ReactNode; // Optional custom renderer
  }[];
  itemsPerPage?: number;
}

type SortKey<T> = keyof T | null;

export const DataTable = <T extends object>({ data, columns, itemsPerPage = 10 }: DataTableProps<T>) => {
  const [sortKey, setSortKey] = useState<SortKey<T>>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  
  // 2. Sorting Logic (Memoized for Performance)
  const sortedData = useMemo(() => {
    if (!sortKey) return data;
    
    return [...data].sort((a, b) => {
      const aValue = a[sortKey as keyof T];
      const bValue = b[sortKey as keyof T];

      if (aValue === bValue) return 0;
      
      let comparison = 0;
      if (aValue > bValue) comparison = 1;
      if (aValue < bValue) comparison = -1;

      return sortDirection === 'asc' ? comparison : comparison * -1;
    });
  }, [data, sortKey, sortDirection]);

  // 3. Pagination Logic
  const totalPages = Math.ceil(sortedData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return sortedData.slice(start, end);
  }, [sortedData, currentPage, itemsPerPage]);

  const handleSort = (key: SortKey<T>) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
    setCurrentPage(1); // Reset page on new sort
  };

  const renderSortIcon = (key: SortKey<T>) => {
    if (sortKey !== key) return null;
    return sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            {columns.map((column) => (
              <th
                key={String(column.key)}
                scope="col"
                className={`px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider ${column.key !== 'actions' ? 'cursor-pointer hover:bg-slate-100 transition-colors' : ''}`}
                onClick={() => column.key !== 'actions' && handleSort(column.key as SortKey<T>)}
              >
                <div className="flex items-center gap-1">
                  {column.header}
                  {renderSortIcon(column.key as SortKey<T>)}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {paginatedData.length > 0 ? paginatedData.map((item, index) => (
            <tr key={index} className="hover:bg-slate-50 transition-colors">
              {columns.map((column) => (
                <td key={String(column.key)} className="px-6 py-4 whitespace-nowrap text-sm text-slate-800">
                  {column.render ? column.render(item) : String(item[column.key as keyof T])}
                </td>
              ))}
            </tr>
          )) : (
            <tr>
                <td colSpan={columns.length} className="px-6 py-4 text-center text-slate-500 text-sm">
                    No matching data found.
                </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* 4. Pagination Controls */}
      {totalPages > 1 && (
        <div className="px-6 py-3 flex items-center justify-between border-t border-slate-200">
          <button
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="p-2 border rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-50"
            aria-label="Previous Page"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="text-sm text-slate-600">
            Page **{currentPage}** of **{totalPages}**
          </span>
          <button
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="p-2 border rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-50"
            aria-label="Next Page"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
};