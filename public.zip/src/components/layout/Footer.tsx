import React from 'react';
import { Facebook, Twitter, Linkedin, Github } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Left: Copyright */}
          <div className="text-sm">
            <p>&copy; {currentYear} Enterprise Corp. All rights reserved.</p>
          </div>

          {/* Middle: Privacy & Legal */}
          <div className="flex gap-6 text-sm font-medium">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
            <Link to="/cookies" className="hover:text-white transition-colors">Cookie Settings</Link>
          </div>

          {/* Right: Social Networks */}
          <div className="flex gap-4">
            <a href="#" aria-label="Facebook" className="hover:text-blue-500 transition-colors"><Facebook size={20} /></a>
            <a href="#" aria-label="Twitter" className="hover:text-sky-400 transition-colors"><Twitter size={20} /></a>
            <a href="#" aria-label="LinkedIn" className="hover:text-blue-600 transition-colors"><Linkedin size={20} /></a>
            <a href="#" aria-label="GitHub" className="hover:text-white transition-colors"><Github size={20} /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};