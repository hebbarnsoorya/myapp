import React, { useContext, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { 
  Menu, X, Settings, User, LogOut, 
  LayoutGrid, ShoppingBag, Bell 
} from 'lucide-react';

export const Header = () => {
  const { state, dispatch } = useContext(AuthContext);
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
    navigate('/login');
  };

  // Helper for active link styling
  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `text-sm font-medium transition-colors hover:text-indigo-600 ${
      isActive ? 'text-indigo-600' : 'text-slate-600'
    }`;

  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* 1. Left: Enterprise Logo & Name (Stacked) */}
          <Link to="/" className="flex flex-col items-start justify-center group">
            {/* Logo Div */}
            <div className="bg-indigo-600 text-white p-1 rounded-md mb-0.5 group-hover:bg-indigo-700 transition-colors">
              <LayoutGrid size={20} />
            </div>
            {/* Name Div */}
            <div className="text-xs font-bold text-slate-800 uppercase tracking-wider group-hover:text-indigo-600 transition-colors">
              DataCorp
            </div>
          </Link>

          {/* 2. Middle: Product Categories (Desktop) */}
          <nav className="hidden md:flex items-center gap-8">
            <NavLink to="/dashboard" className={navLinkClass}>
                Dashboard
            </NavLink>
            <NavLink to="/category" className={navLinkClass}>
              Categories
            </NavLink>
            <NavLink to="/products" className={navLinkClass}>
              Products
            </NavLink>
            <NavLink to="/analytics" className={navLinkClass}>
              Analytics
            </NavLink>

            <NavLink to="/users" className={navLinkClass}>
                Users
            </NavLink>
          </nav>

          {/* 3. Right: Configuration & Profile (Desktop) */}
          <div className="hidden md:flex items-center gap-4">
            {state.isAuthenticated ? (
              <>
                <button aria-label="Notifications" className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-full transition-all">
                  <Bell size={20} />
                </button>
                <button aria-label="Settings" className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-full transition-all">
                  <Settings size={20} />
                </button>
                
                <div className="h-6 w-px bg-slate-200 mx-2"></div>

                <div className="flex items-center gap-3">
                  <div className="flex flex-col items-end">
                     <span className="text-sm font-semibold text-slate-700">{state.user?.name || 'User'}</span>
                     <span className="text-xs text-slate-500">Admin</span>
                  </div>
                  <div className="h-9 w-9 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center border border-indigo-200">
                    <User size={18} />
                  </div>
                </div>

                <button 
                  onClick={handleLogout} 
                  className="ml-2 p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  title="Logout"
                >
                  <LogOut size={20} />
                </button>
              </>
            ) : (
              <Link to="/login" className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-shadow shadow-sm">
                Login
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-600 hover:bg-slate-100 rounded-md"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 absolute w-full shadow-lg">
          <div className="px-4 pt-2 pb-6 space-y-2">
            <Link to="/dashboard" className="block py-2 text-slate-600 font-medium hover:text-indigo-600">Dashboard</Link>
            <Link to="/users" className="block py-2 text-slate-600 font-medium hover:text-indigo-600">Users</Link>
            <Link to="/category" className="block py-2 text-slate-600 font-medium hover:text-indigo-600">Categories</Link>
            <Link to="/products" className="block py-2 text-slate-600 font-medium hover:text-indigo-600">Products</Link>
            <hr className="border-slate-100 my-2" />
            <Link to="/settings" className="block py-2 text-slate-600 hover:text-indigo-600 flex items-center gap-2"><Settings size={18}/> Settings</Link>
            <button onClick={handleLogout} className="w-full text-left py-2 text-red-500 font-medium flex items-center gap-2"><LogOut size={18}/> Logout</button>
          </div>
        </div>
      )}
    </header>
  );
};