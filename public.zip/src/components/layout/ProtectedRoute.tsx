import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';

export const ProtectedRoute = () => {
  const { state } = useContext(AuthContext);
  const location = useLocation();

  // 1. Session Check
  if (!state.isAuthenticated) {
    // Redirect to login, but save the current location they tried to access
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. Render child routes (The Dashboard)
  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar could go here */}
      <main className="flex-1 transition-all duration-300">
         {/* Outlet renders the matched child route */}
        <Outlet /> 
      </main>
    </div>
  );
};